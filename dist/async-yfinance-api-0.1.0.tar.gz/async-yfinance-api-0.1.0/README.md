async-yfinance-api
==================

Asynchronous Python module to get stock, cryptocurrency, and ETF data from Yahoo! Finance.

Install from repository:
    
    pip3 install git+https://github.com/aLEGEND21/async-yfinance-api.git

Available Functions
-------------------

- ``await fetch_summary()``
